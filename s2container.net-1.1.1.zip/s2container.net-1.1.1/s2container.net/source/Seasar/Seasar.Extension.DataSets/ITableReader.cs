using System.Data;

namespace Seasar.Extension.DataSets
{
	public interface ITableReader
	{
		DataTable Read();
	}
}
