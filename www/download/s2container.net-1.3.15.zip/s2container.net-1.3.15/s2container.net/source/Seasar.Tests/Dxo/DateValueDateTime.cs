using System;

namespace Seasar.Tests.Dxo
{
    /// <summary>
    /// ���t��DateTime�Ŏ���
    /// </summary>
    public class DateValueDateTime
    {
        private DateTime _dateValue;

        public DateTime DateValue
        {
            get { return _dateValue; }
            set { _dateValue = value; }
        }
    }
}