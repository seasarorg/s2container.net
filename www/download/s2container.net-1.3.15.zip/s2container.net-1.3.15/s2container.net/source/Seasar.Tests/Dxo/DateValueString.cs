namespace Seasar.Tests.Dxo
{
    /// <summary>
    /// ���t�𕶎���Ŏ���
    /// </summary>
    public class DateValueString
    {
        private string _dateValue;

        public string DateValue
        {
            get { return _dateValue; }
            set { _dateValue = value; }
        }
    }
}