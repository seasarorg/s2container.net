#region Copyright
/*
 * Copyright 2005-2007 the Seasar Foundation and the Others.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
#endregion

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

using Seasar.Extension.UI;
using Seasar.Extension.UI.Forms;
using Seasar.Framework.Util;

namespace Seasar.Examples
{
	/// <summary>
	/// ExamplesExplorer �̊T�v�̐����ł��B
	/// </summary>
	public class ExamplesExplorer : System.Windows.Forms.Form
	{
		private ExamplesContext examplesContext;
		private TextAppender ResultAppender;
		private TextAppender DiconAppender;
		private TextAppender CodeAppender;

		private System.Windows.Forms.TreeView MainTreeView;
		private System.Windows.Forms.TabControl MainTabControl;
		private System.Windows.Forms.TabPage ResultConsole;
		private System.Windows.Forms.TabPage DiconConsole;
		private System.Windows.Forms.TabPage CodeConsole;
		private System.Windows.Forms.TextBox ResultView;
		private SyntaxHighlightingTextBox DiconView;
		private SyntaxHighlightingTextBox CodeView;
		private System.Windows.Forms.ContextMenu FontContextMenu;
		private System.Windows.Forms.MenuItem ScalingUp;
		private System.Windows.Forms.MenuItem ScalingDown;
		private System.Windows.Forms.MenuItem SelectFont;
		private Splitter Splitter;
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		private System.ComponentModel.Container components = null;

		public ExamplesExplorer()
		{
			//
			// Windows �t�H�[�� �f�U�C�i �T�|�[�g�ɕK�v�ł��B
			//
			InitializeComponent();
			this.examplesContext = new ExamplesContext();
			this.examplesContext.ResultViewChanged += new ResultViewChangedEventHandler(this.ResultViewChanged);
			
			ResultAppender = new TextAppender(ResultView);
			Console.SetOut(ResultAppender);
			Console.SetError(ResultAppender);

			DiconAppender = new TextAppender(DiconView);
			CodeAppender = new TextAppender(CodeView);

			SetUpHighlighting(new Font("MS UI Gothic", 10,FontStyle.Bold));
		}

		private void SetUpHighlighting(Font font)
		{
			// TODO �F�t���̒�`���Y���Y���ƃR�R�ɂ���̂̓`�g�C�}�C�`�c�B
			string[] keywords_tags = {"components", "include", "component", "description",
										 "arg", "property", "meta", "initMethod", "destroyMethod", "aspect" };
			addHighlightDescriptors(keywords_tags, Color.Blue, font);

			string[] keywords_attributs = {"path", "instance", "class", "name",
											  "autoBinding", "getter", "pointcut"};
			addHighlightDescriptors(keywords_attributs, Color.Magenta, font);

			string[] keywords_literals = {"singleton", "prototype", "outer", "request", "session",
											 "auto", "constructor", "property", "none",
											 "true", "false"};
			addHighlightDescriptors(keywords_literals, Color.Maroon, font);
			
			DiconView.HighlightDescriptors.Add(new HighlightDescriptor("<!--", "-->", Color.Green, font, DescriptorType.ToCloseToken, DescriptorRecognition.StartsWith));
		}

		private void addHighlightDescriptors(string[] keywords, Color color, Font font)
		{
			foreach(string word in keywords) 
			{
				DiconView.HighlightDescriptors.Add(new HighlightDescriptor(word, color, font, DescriptorType.Word, DescriptorRecognition.WholeWord));
			}
		}

		/// <summary>
		/// �g�p����Ă��郊�\�[�X�Ɍ㏈�������s���܂��B
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
				ResultAppender.Close();
				DiconAppender.Close();
				CodeAppender.Close();
			}
			base.Dispose( disposing );
		}

		#region Windows �t�H�[�� �f�U�C�i�Ő������ꂽ�R�[�h 
		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		private void InitializeComponent()
		{
			this.MainTreeView = new System.Windows.Forms.TreeView();
			this.MainTabControl = new System.Windows.Forms.TabControl();
			this.ResultConsole = new System.Windows.Forms.TabPage();
			this.ResultView = new System.Windows.Forms.TextBox();
			this.DiconConsole = new System.Windows.Forms.TabPage();
			this.CodeConsole = new System.Windows.Forms.TabPage();
			this.FontContextMenu = new System.Windows.Forms.ContextMenu();
			this.ScalingUp = new System.Windows.Forms.MenuItem();
			this.ScalingDown = new System.Windows.Forms.MenuItem();
			this.SelectFont = new System.Windows.Forms.MenuItem();
			this.Splitter = new System.Windows.Forms.Splitter();
			this.DiconView = new Seasar.Extension.UI.Forms.SyntaxHighlightingTextBox();
			this.CodeView = new Seasar.Extension.UI.Forms.SyntaxHighlightingTextBox();
			this.MainTabControl.SuspendLayout();
			this.ResultConsole.SuspendLayout();
			this.DiconConsole.SuspendLayout();
			this.CodeConsole.SuspendLayout();
			this.SuspendLayout();
			// 
			// MainTreeView
			// 
			this.MainTreeView.Dock = System.Windows.Forms.DockStyle.Left;
			this.MainTreeView.Location = new System.Drawing.Point(0, 0);
			this.MainTreeView.Name = "MainTreeView";
			this.MainTreeView.Size = new System.Drawing.Size(168, 365);
			this.MainTreeView.TabIndex = 0;
			this.MainTreeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.MainTreeView_AfterSelect);
			// 
			// MainTabControl
			// 
			this.MainTabControl.Controls.Add(this.ResultConsole);
			this.MainTabControl.Controls.Add(this.DiconConsole);
			this.MainTabControl.Controls.Add(this.CodeConsole);
			this.MainTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.MainTabControl.Location = new System.Drawing.Point(168, 0);
			this.MainTabControl.Name = "MainTabControl";
			this.MainTabControl.SelectedIndex = 0;
			this.MainTabControl.Size = new System.Drawing.Size(564, 365);
			this.MainTabControl.TabIndex = 1;
			// 
			// ResultConsole
			// 
			this.ResultConsole.Controls.Add(this.ResultView);
			this.ResultConsole.Location = new System.Drawing.Point(4, 21);
			this.ResultConsole.Name = "ResultConsole";
			this.ResultConsole.Size = new System.Drawing.Size(556, 340);
			this.ResultConsole.TabIndex = 0;
			this.ResultConsole.Text = "ResultConsole";
			// 
			// ResultView
			// 
			this.ResultView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ResultView.Location = new System.Drawing.Point(0, 0);
			this.ResultView.Multiline = true;
			this.ResultView.Name = "ResultView";
			this.ResultView.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
			this.ResultView.Size = new System.Drawing.Size(556, 340);
			this.ResultView.TabIndex = 2;
			this.ResultView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.View_MouseDown);
			// 
			// DiconConsole
			// 
			this.DiconConsole.Controls.Add(this.DiconView);
			this.DiconConsole.Location = new System.Drawing.Point(4, 21);
			this.DiconConsole.Name = "DiconConsole";
			this.DiconConsole.Size = new System.Drawing.Size(556, 340);
			this.DiconConsole.TabIndex = 1;
			this.DiconConsole.Text = "DiconConsole";
			// 
			// CodeConsole
			// 
			this.CodeConsole.Controls.Add(this.CodeView);
			this.CodeConsole.Location = new System.Drawing.Point(4, 21);
			this.CodeConsole.Name = "CodeConsole";
			this.CodeConsole.Size = new System.Drawing.Size(556, 340);
			this.CodeConsole.TabIndex = 2;
			this.CodeConsole.Text = "CodeConsole";
			// 
			// FontContextMenu
			// 
			this.FontContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.ScalingUp,
            this.ScalingDown,
            this.SelectFont});
			// 
			// ScalingUp
			// 
			this.ScalingUp.Index = 0;
			this.ScalingUp.Text = "�g��";
			this.ScalingUp.Click += new System.EventHandler(this.ScalingUp_Click);
			// 
			// ScalingDown
			// 
			this.ScalingDown.Index = 1;
			this.ScalingDown.Text = "�k��";
			this.ScalingDown.Click += new System.EventHandler(this.ScalingDown_Click);
			// 
			// SelectFont
			// 
			this.SelectFont.Index = 2;
			this.SelectFont.Text = "�t�H���g�I��";
			this.SelectFont.Click += new System.EventHandler(this.SelectFont_Click);
			// 
			// Splitter
			// 
			this.Splitter.Location = new System.Drawing.Point(0, 0);
			this.Splitter.Name = "Splitter";
			this.Splitter.Size = new System.Drawing.Size(3, 340);
			this.Splitter.TabIndex = 3;
			this.Splitter.TabStop = false;
			// 
			// DiconView
			// 
			this.DiconView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.DiconView.Location = new System.Drawing.Point(0, 0);
			this.DiconView.Name = "DiconView";
			this.DiconView.Size = new System.Drawing.Size(556, 340);
			this.DiconView.TabIndex = 1;
			this.DiconView.Text = "";
			this.DiconView.WordWrap = false;
			this.DiconView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.View_MouseDown);
			// 
			// CodeView
			// 
			this.CodeView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.CodeView.Location = new System.Drawing.Point(0, 0);
			this.CodeView.Name = "CodeView";
			this.CodeView.Size = new System.Drawing.Size(556, 340);
			this.CodeView.TabIndex = 0;
			this.CodeView.Text = "";
			this.CodeView.WordWrap = false;
			this.CodeView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.View_MouseDown);
			// 
			// ExamplesExplorer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
			this.ClientSize = new System.Drawing.Size(732, 365);
			this.Controls.Add(this.MainTabControl);
			this.Controls.Add(this.Splitter);
			this.Controls.Add(this.MainTreeView);
			this.Name = "ExamplesExplorer";
			this.Text = "ExamplesExplorer";
			this.MainTabControl.ResumeLayout(false);
			this.ResultConsole.ResumeLayout(false);
			this.ResultConsole.PerformLayout();
			this.DiconConsole.ResumeLayout(false);
			this.CodeConsole.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public void AddExamples(string title, IList exampless) 
		{
			TreeNode rootNode = new TreeNode(title);
			foreach(IExamplesHandler handler in exampless) 
			{
				rootNode.Nodes.Add(new ExecutableTreeNode(handler));
			}
			this.MainTreeView.Nodes.Add(rootNode);
		}

		private void ResultViewChanged(Control ctrl) 
		{
			this.SuspendLayout();
			this.ResultConsole.SuspendLayout();

			this.ResultConsole.Controls.Clear();
			ctrl.Dock = System.Windows.Forms.DockStyle.Fill;
			ctrl.Size = this.ResultView.Size;
			this.ResultConsole.Controls.Add(ctrl);

			this.ResultConsole.ResumeLayout(false);
			this.ResumeLayout(false);
		}

		private void MainTreeView_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			Cursor = Cursors.WaitCursor;
			try 
			{
				this.ResultView.Clear();
				this.CodeView.Clear();
				this.DiconView.Clear();
				if(e.Node is ExecutableTreeNode) 
				{
					ExecutableTreeNode etn = e.Node as ExecutableTreeNode;
					this.ResultViewChanged(this.ResultView); // ���͂Ƃ�����f�t�H���g�̕\���͏o����l�ɂ���B
					etn.ExamplesHandler.Main(examplesContext);
					etn.ExamplesHandler.AppendDicon(this.DiconAppender);
					this.DiconView.ProcessHighlighting();
					etn.ExamplesHandler.AppendCode(this.CodeAppender);
					this.CodeView.ProcessHighlighting();
				}
			}
			finally
			{
				Cursor = Cursors.Arrow;
			}
		}

		#region font settings

		private void View_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if(MouseButtons.Right == e.Button)
			{
				this.FontContextMenu.Show(sender as Control,new Point(e.X,e.Y));
			}
		}

		private void ScalingUp_Click(object sender, System.EventArgs e)
		{
			Control c = GetSourceControl(sender);
			if(c != null)
			{
				this.Scale(new Font(c.Font.FontFamily, c.Font.Size + 1));
			}
		}

		private void ScalingDown_Click(object sender, System.EventArgs e)
		{
			Control c = GetSourceControl(sender);
			if(c != null)
			{
				float size = c.Font.Size - 1;
				if(5 < size)
				{
					this.Scale(new Font(c.Font.FontFamily, size));
				}
			}
		}

		private Control GetSourceControl(object sender)
		{
			Control result = null;
			MenuItem mi = sender as MenuItem;
			if(mi != null)
			{
				result = mi.GetContextMenu().SourceControl;
			}

			return result;
		}

		private void SelectFont_Click(object sender, System.EventArgs e)
		{
			FontDialog dialog = new FontDialog();
			dialog.AllowVerticalFonts = true;
			dialog.ScriptsOnly = true;
			dialog.ShowEffects = false;

			if(dialog.ShowDialog(this) == DialogResult.OK)
			{
				this.Scale(dialog.Font);
			}
		}

		private void Scale(Font font)
		{
			this.SuspendLayout();
			foreach(TabPage tp in this.MainTabControl.Controls)
			{
				tp.Controls[0].SuspendLayout();
			}

			foreach(TabPage tp in this.MainTabControl.Controls)
			{
				tp.Controls[0].Font = font;
			}

			this.Refresh();
			this.SetUpHighlighting(new Font(font.FontFamily,font.Size,FontStyle.Bold));
			this.DiconView.ProcessHighlighting();
			this.CodeView.ProcessHighlighting();

			foreach(TabPage tp in this.MainTabControl.Controls)
			{
				tp.Controls[0].ResumeLayout();
			}
			this.ResumeLayout();
		}

		#endregion
	}
}
