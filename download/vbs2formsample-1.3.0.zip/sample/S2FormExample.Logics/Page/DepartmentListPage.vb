''
'' Copyright 2005-2007 the Seasar Foundation and the Others.
''
'' Licensed under the Apache License, Version 2.0 (the "License");
'' you may not use this file except in compliance with the License.
'' You may obtain a copy of the License at
''
''     http://www.apache.org/licenses/LICENSE-2.0
''
'' Unless required by applicable law or agreed to in writing, software
'' distributed under the License is distributed on an "AS IS" BASIS,
'' WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
'' either express or implied. See the License for the specific language
'' governing permissions and limitations under the License.
''
Imports Seasar.S2FormExample.Logics.Dto

Namespace Page
    ''' <summary>
    ''' ����ꗗPage�N���X
    ''' </summary>
    ''' <remarks></remarks>
    Public Class DepartmentListPage
        ''' <summary>
        ''' ����ꗗ
        ''' </summary>
        ''' <remarks></remarks>
        Private _list As IList(Of DepartmentDto)

        ''' <summary>
        ''' �R���X�g���N�^
        ''' </summary>
        ''' <remarks></remarks>
        Public Sub New()
            _list = New List(Of DepartmentDto)
        End Sub

        ''' <summary>
        ''' ����ꗗ
        ''' </summary>
        ''' <remarks></remarks>
        Public Property List() As IList(Of DepartmentDto)
            Get
                Return _list
            End Get
            Set(ByVal value As IList(Of DepartmentDto))
                _list = value
            End Set
        End Property
    End Class
End Namespace